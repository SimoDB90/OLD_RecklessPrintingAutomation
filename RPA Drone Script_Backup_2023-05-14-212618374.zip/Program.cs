﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        /// <summary>
        /// Changelog V 2.1 (26/04/2023):
        /// Fix bug of rotor speed;
        /// Added rotor speed to log and lcd panel
        /// Fix bug when setup command was ran, that forced the drone to start the process
        /// 
        /// Chngelog V 2.0 (26/04/2023):
        /// Get rid of naming conventio, and add tag requirment to the blocks/groups.Default is [RPA], but you can always change it in CustomData of the Station's script;
        /// All logs should be now polished, meaning, if you forgot any tag or block, you'll see in the PB log or the station's LCD panel; In general, more informations are printed;
        /// All variables that can be changed in CustomData of the Drone, have been moved in the Station's PB CustomData, so, if you want to change any of them, youu don't need anymore to reach the Drone's PB (Engineers are lazy!);
        /// Station's PB CustomData have more variables: RotorSpeed; DynamicRotorCheck; DynamicSpeed (see Station Setup chapter);
        /// A new configuration is possible: DynamicRotorCheck, to have better chance to cover all blocks(See Tuning Chapter);
        /// Added list of commands in the Station's PB log;
        /// </summary>
        readonly MyIni _ini = new MyIni();
        double Wait;
        double ImWait = 25;
        readonly IMyBroadcastListener _myBroadcastListener;
        bool setupCompleted;
        readonly List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
        readonly List<IMyShipController> CockpitList = new List<IMyShipController>();
        readonly List<IMyProjector> ProjectorList = new List<IMyProjector>();
        readonly List<IMyThrust> ThrusterGroup = new List<IMyThrust>();

        IMyShipController Cockpit;
        IMyProjector Projector;
        readonly string BroadcastTag = "channel_1";

        const string TagDefault = "[RPA]";

        Vector3D start;

        bool checkDistance;
        float thrust;
        float mass;
        readonly float acceleration = 0.4f; //wanted acceleration in m/s^2

        readonly string TagCustom;
        readonly int ThrustersInGroup;


        /// Rotor's setting
        bool firstRotation = true;
        bool RotorDynamicSpeed = true;
        float DynamicSpeed = 20f;
        float RotorSpeed;
        float newRotorSpeed;

        public Program()
        {

            //////////////////
            //get and set for customdata
            bool wasParsed = _ini.TryParse(Me.CustomData);
            TagCustom = _ini.Get("data", "TAG").ToString(TagDefault);

            if (!wasParsed)
            {
                _ini.Clear();
            }
            // Set the values to make sure they exist. They could be missing even when parsed ok.
            _ini.Set("data", "TAG", TagCustom);

            Me.CustomData = _ini.ToString();
            ///////////////////////////

            /////////////////////////
            ///Listener (Antenna Inter Grid Communication)
            start = Me.GetPosition();
            Echo("Drone");
            _myBroadcastListener = IGC.RegisterBroadcastListener(BroadcastTag);
            _myBroadcastListener.SetMessageCallback(BroadcastTag);
            ////////////////////////////////////////
            ///SETUP//////////////////////

            SetupBlocks();
            if (setupCompleted)
            {
                ThrustersInGroup = ThrusterGroup.Count;
                Echo("Numbers of thrusters in group: " + $"{ThrustersInGroup}\nCockpit Found \nProjector Found \nTag used: [{TagCustom}]");
                IGC.SendBroadcastMessage(BroadcastTag, $"Numbers of thrusters in the group: {ThrustersInGroup} \nCockpit Found \nProjector Found \nTag used: [{TagCustom}]");
            }

        }

        public void Main(string argument, UpdateType updateSource)
        {
            if (!RotorDynamicSpeed)
            {
                if (checkDistance && Vector3D.Distance(start, Me.GetPosition()) >= 1.5)
                {
                    DistanceCheck(ThrusterGroup);
                }
                if (Wait > 0)
                {
                    ActionTime(Cockpit, Projector, ThrusterGroup);
                }
                if ((updateSource & UpdateType.IGC) > 0)
                {
                    ImListening(Cockpit, Projector, ThrusterGroup);
                }
            }

            else if (RotorDynamicSpeed)
            {
                if (checkDistance && Vector3D.Distance(start, Me.GetPosition()) >= 1.5)
                {
                    DistanceCheck(ThrusterGroup: ThrusterGroup);
                }
                if (Wait >= 0.7 * ImWait && firstRotation)
                {
                    RotorSpeedingUp();
                    ActionTime(Cockpit, Projector, ThrusterGroup);

                }

                else if (!checkDistance)
                {
                    RotorSpeedingDown();
                    ActionTime(Cockpit, Projector, ThrusterGroup);
                }

                if ((updateSource & UpdateType.IGC) > 0)
                {
                    ImListening(Cockpit, Projector, ThrusterGroup);
                }
            }
        }


        public void RotorSpeedingUp()
        {
            newRotorSpeed = DynamicSpeed;
            IGC.SendBroadcastMessage(BroadcastTag, newRotorSpeed);
        }

        public void RotorSpeedingDown()
        {
            newRotorSpeed = RotorSpeed;
            IGC.SendBroadcastMessage(BroadcastTag, newRotorSpeed);
        }

        public void ActionTime(IMyShipController Cockpit, IMyProjector Projector, List<IMyThrust> ThrusterGroup)
        {
            Wait -= Runtime.TimeSinceLastRun.TotalSeconds;
            mass = Cockpit.CalculateShipMass().PhysicalMass;
            GridTerminalSystem.GetBlocksOfType<IMyTerminalBlock>(blocks, b => !b.IsFunctional);
            Runtime.UpdateFrequency = UpdateFrequency.Update10;

            /// Number of buildable blocks
            if (Projector.IsProjecting)
            {
                int remaining = Projector.RemainingBlocks;
                string output = $"Total remaining blocks: " +
                    $"{Projector.RemainingBlocks}; \n" +
                    $"Missing Terminal blocks for section: {blocks.Count};\n" +
                    $"Seconds till next check: {Math.Round(Wait)};\n" +
                    $"Distance: {Math.Round(Vector3D.Distance(start, Me.GetPosition()), 2)} meters;\n" +
                    $"Grid Total Mass {mass / 1000f} tons;\n" +
                    $"Dynamic Rotor {RotorDynamicSpeed};\n" +
                    $"Rotor Speed {newRotorSpeed} RPM;";
                Echo(output);
                IGC.SendBroadcastMessage(BroadcastTag, output);
            }

            if (Wait <= 0)
            {
                int remaining = Projector.RemainingBlocks;
                GridTerminalSystem.GetBlocksOfType<IMyTerminalBlock>(blocks, b => !b.IsFunctional);
                Runtime.UpdateFrequency = UpdateFrequency.Update10;
                string output = $"Total remaining blocks: " +
                    $"{Projector.RemainingBlocks}; \n" +
                    $"Missing Terminal blocks for section: {blocks.Count};\n" +
                    $"Seconds till next check: {Math.Round(Wait)};\n" +
                    $"Distance: {Math.Round(Vector3D.Distance(start, Me.GetPosition()), 2)} meters;\n" +
                    $"Grid Total Mass {mass / 1000f} tons;\n" +
                    $"Dynamic Rotor {RotorDynamicSpeed};\n" +
                    $"Rotor Speed {newRotorSpeed} RPM;";
                Echo(output);
                IGC.SendBroadcastMessage(BroadcastTag, output);

                if (blocks.Count > 0)
                {
                    mass = Cockpit.CalculateShipMass().PhysicalMass;
                    Wait = ImWait;
                    firstRotation = false;
                    Echo(output);
                    IGC.SendBroadcastMessage(BroadcastTag, output);
                }


                if (blocks.Count == 0)
                {
                    start = Me.GetPosition();
                    Echo("Section finished, let's go back!");
                    IGC.SendBroadcastMessage(BroadcastTag, "Section finished, let's go back! \n");
                    Movement(Cockpit, ThrusterGroup);
                }

                //check for stopping status (finished printing)
                int unweldable_blocks = Projector.RemainingBlocks;
                if (unweldable_blocks == 0)
                {
                    Runtime.UpdateFrequency = UpdateFrequency.None;
                    Wait = 0;
                    Echo("Ship Printed! Yikes!!");
                    IGC.SendBroadcastMessage(BroadcastTag, "Ship is printed! Yikes \n");
                    Stop(ThrusterGroup);
                    checkDistance = false;
                    firstRotation = false;
                    return;
                }

            }
        }

        public void SetupBlocks()
        {
            List<IMyBlockGroup> ThrustersGroupsList = new List<IMyBlockGroup>();
            GridTerminalSystem.GetBlockGroups(ThrustersGroupsList, x => x.Name.Contains(TagCustom));
            if (!ThrustersGroupsList.Any() || ThrustersGroupsList.Count > 1 || ThrustersGroupsList == null)
            {
                Echo($"Thrusters group not found or more than 1 Thruster Group found \nUse the [{TagDefault}] tag, or change it in Custom Data");
                IGC.SendBroadcastMessage(BroadcastTag, $"Thrusters not found or more than 1 Thruster Group found \nUse [{TagDefault}] tag, or change it in Custom Data");
                return;
            }
            ThrustersGroupsList[0].GetBlocksOfType(ThrusterGroup);

            GridTerminalSystem.GetBlocksOfType(CockpitList, x => x.CustomName.Contains(TagCustom));
            if (!CockpitList.Any() || CockpitList.Count > 1 || CockpitList == null)
            {
                Echo($"No Cockpit found or more than 1 Cockpit found \nUse [{TagDefault}] tag, or change it in Custom Data");
                IGC.SendBroadcastMessage(BroadcastTag, $"No Cockpit found (mandatory) or more than 1 Cockpit found \nUse [{TagDefault}] tag, or change it in Custom Data");
                return;
            }
            Cockpit = CockpitList[0];

            GridTerminalSystem.GetBlocksOfType(ProjectorList, x => x.CustomName.Contains(TagCustom));
            if (!ProjectorList.Any() || ProjectorList.Count > 1 || ProjectorList == null)
            {
                Echo($"No Projector found or more than 1 Projector found \nUse [{TagDefault}] tag, or change it in Custom Data");
                IGC.SendBroadcastMessage(BroadcastTag, $"No Projector found (mandatory) or more than 1 Projector found \nUse [{TagDefault}] tag, or change it in Custom Data");
                return;
            }
            Projector = ProjectorList[0];

            setupCompleted = true;
        }

        void ImListening(IMyShipController Cockpit, IMyProjector Projector, List<IMyThrust> ThrusterGroup)
        {
            while (_myBroadcastListener.HasPendingMessage)
            {
                var myIGCMessage = _myBroadcastListener.AcceptMessage();
                if (myIGCMessage.Tag == BroadcastTag && myIGCMessage.Data is string)
                {

                    switch (myIGCMessage.Data.ToString())
                    {
                        case "start":
                            Wait = ImWait;
                            Runtime.UpdateFrequency = UpdateFrequency.Update100;
                            mass = Cockpit.CalculateShipMass().PhysicalMass;
                            GridTerminalSystem.GetBlocksOfType<IMyTerminalBlock>(blocks, b => !b.IsFunctional);
                            string output = $"Total remaining blocks: " +
                                $"{Projector.RemainingBlocks}; \n" +
                                $"Missing Terminal blocks for section: {blocks.Count};\n" +
                                $"Seconds till next check: {Math.Round(Wait)};\n" +
                                $"Distance: {Math.Round(Vector3D.Distance(start, Me.GetPosition()), 2)} meters;\n" +
                                $"Grid Total Mass {mass / 1000f} tons;\n" +
                                $"Dynamic Rotor = {RotorDynamicSpeed};\n" +
                                $"Rotor Speed = {newRotorSpeed} RPM;";
                            Echo(output);
                            IGC.SendBroadcastMessage(BroadcastTag, output);
                            firstRotation = true;
                            break;

                        case "projector":
                            Projecting(Projector);
                            break;


                        case "stop":
                            Runtime.UpdateFrequency = UpdateFrequency.None;
                            Wait = 0;
                            checkDistance = false;
                            Stop(ThrusterGroup);
                            IGC.SendBroadcastMessage(BroadcastTag, "Let's stop doing stuff \n");
                            break;


                        case "skip":
                            start = Me.GetPosition();
                            Movement(Cockpit, ThrusterGroup);
                            IGC.SendBroadcastMessage(BroadcastTag, "Let's move back a little bit \n");
                            break;
                    }
                }

                if (myIGCMessage.Data is MyTuple<string, double, float, bool, float>)
                {
                    var tuple = (MyTuple<string, double, float, bool, float>)myIGCMessage.Data;
                    string setup = tuple.Item1;
                    ImWait = tuple.Item2;
                    DynamicSpeed = tuple.Item3;
                    RotorDynamicSpeed = tuple.Item4;
                    RotorSpeed = tuple.Item5;
                    string output = $"Setup completed:\nWait = {ImWait} seconds;\nRotor Speed = {RotorSpeed} RPM;\nDynamic Control = {RotorDynamicSpeed};\nDynamic Speed = {DynamicSpeed} RPM";
                    Echo(output);
                    IGC.SendBroadcastMessage(BroadcastTag, output);
                    Wait = 0;
                    Stop(ThrusterGroup);
                    Runtime.UpdateFrequency = UpdateFrequency.None;
                    checkDistance = false;
                }
            }
        }

        public void Projecting(IMyProjector Projector)
        {
            Projector.Enabled = !Projector.Enabled;
            IGC.SendBroadcastMessage(BroadcastTag, "Projector On/Off \n");
        }

        public void Movement(IMyShipController Cockpit, List<IMyThrust> ThrusterGroup)
        {
            checkDistance = true;
            firstRotation = false;

            Runtime.UpdateFrequency = UpdateFrequency.Update10;
            mass = Cockpit.CalculateShipMass().PhysicalMass;
            string output = $"Total remaining blocks: " +
                                $"{Projector.RemainingBlocks}; \n" +
                                $"Missing Terminal blocks for section: {blocks.Count};\n" +
                                $"Seconds till next check: {Math.Round(Wait)};\n" +
                                $"Distance: {Math.Round(Vector3D.Distance(start, Me.GetPosition()), 2)} meters;\n" +
                                $"Grid Total Mass {mass / 1000f} tons;\n" +
                                $"Dynamic Rotor = {RotorDynamicSpeed};\n" +
                                $"Rotor Speed = {newRotorSpeed} RPM;";
            Echo(output);
            IGC.SendBroadcastMessage(BroadcastTag, output);
            thrust = (mass * acceleration) / (ThrustersInGroup);


            foreach (var thrusters in ThrusterGroup)
            {
                thrusters.ThrustOverride = thrust;
            }

        }

        public void DistanceCheck(List<IMyThrust> ThrusterGroup)
        {
            //check if distance has been covered
            checkDistance = false;
            Stop(ThrusterGroup);
            Wait = ImWait;
            firstRotation = true;
        }

        public void Stop(List<IMyThrust> ThrusterGroup)
        {
            foreach (var thrusters in ThrusterGroup)
            {
                thrusters.ThrustOverride = 0f;
            }
        }


    }
}

