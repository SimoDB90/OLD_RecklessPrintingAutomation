﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        readonly MyIni _ini = new MyIni();

        bool setupCompleted;
        readonly string BroadcastTag = "channel_1";
        readonly IMyBroadcastListener _myBroadcastListener_station;

        const string TagDefault = "[RPA]";
        readonly string TagCustom;

        // Wait variable
        readonly double WaitingCustom;
        const double WaitingDefault = 10;

        //LCD 
        readonly List<IMyTextPanel> LCD_list = new List<IMyTextPanel>();
        IMyTextPanel LCD;
        readonly float fontsize = 0.5f; // font of lcd panel

        /// <Rotor
        readonly List<IMyMotorAdvancedStator> RotorList = new List<IMyMotorAdvancedStator>();
        IMyMotorAdvancedStator Rotor;

        const float DynamicSpeedDefault = 20f;
        readonly float DynamicSpeedCustom;
        const bool RotorDynamicSpeedDefault = false;
        readonly bool RotorDynamicSpeedCustom;
        const float RotorSpeedDefault = 2f;
        readonly float RotorSpeedCustom;
        float RotorTorque;


        public Program()
        {

            /////////////////////////
            ///Listener (Antenna Inter Grid Communication)
            _myBroadcastListener_station = IGC.RegisterBroadcastListener(BroadcastTag);
            _myBroadcastListener_station.SetMessageCallback(BroadcastTag);
            ////////////////////////////////////////
            ///
            //get and set for customdata
            bool wasParsed = _ini.TryParse(Me.CustomData);
            TagCustom = _ini.Get("data", "TAG").ToString(TagDefault);
            WaitingCustom = _ini.Get("data", "Wait").ToDouble(WaitingDefault);
            RotorSpeedCustom = _ini.Get("data", "RotorSpeed").ToSingle(RotorSpeedDefault);
            RotorDynamicSpeedCustom = _ini.Get("data", "DynamicRotorCheck(bool)").ToBoolean(RotorDynamicSpeedDefault);
            DynamicSpeedCustom = _ini.Get("data", "DynamicSpeed(RPM)").ToSingle(DynamicSpeedDefault);


            if (!wasParsed)
            {
                _ini.Clear();
            }
            // Set the values to make sure they exist. They could be missing even when parsed ok.
            _ini.Set("data", "TAG", TagCustom);
            _ini.Set("data", "Wait", WaitingCustom);
            _ini.Set("data", "RotorSpeed", RotorSpeedCustom);
            _ini.Set("data", "DynamicRotorCheck(bool)", RotorDynamicSpeedCustom);
            _ini.Set("data", "DynamicSpeed(RPM)", DynamicSpeedCustom);

            Me.CustomData = _ini.ToString();

            SetupBlocks();
            //Block declarations
            if (setupCompleted)
            {
                string output = $"LCD Found \nRotor Found; Torque set to {RotorTorque / 1000000} MNm ; \nTag used: [[{TagCustom}]]\n" +
                    $"[setup]: send CustomData to Drone;\n" +
                    $"[start]: start the process;\n" +
                    $"[stop]: stop the process;\n" +
                    $"[projector]: turn on/off the Drone's projector\n" +
                    $"[skip]: force drone to move back;";
                Echo(output);
                LCD.WriteText(output);
            }
        }
        public void SetupBlocks()
        {
            GridTerminalSystem.GetBlocksOfType(LCD_list, x => x.CustomName.Contains(TagCustom));
            if (!LCD_list.Any() || LCD_list.Count > 1 || LCD_list == null)
            {
                Echo($"No LCD found or more than 1 LCD found \nUse [{TagDefault}] tag, or change it in Custom Data");
                return;
            }


            GridTerminalSystem.GetBlocksOfType(RotorList, x => x.CustomName.Contains(TagCustom));
            if (!RotorList.Any() || RotorList.Count > 1 || RotorList == null)
            {
                Echo($"No Rotor found or more than 1 Rotor found \nUse [{TagDefault}] tag, or change it in Custom Data");
                return;
            }

            Rotor = RotorList[0];
            RotorTorque = Rotor.Torque = 40000000;
            LCD = LCD_list[0];
            LCD.FontSize = fontsize;
            LCD.Font = "Monospace";
            LCD.ContentType = ContentType.TEXT_AND_IMAGE;

            setupCompleted = true;
        }

        public void Main(string argument, UpdateType updateSource)
        {
            if (
                (updateSource & (UpdateType.Trigger | UpdateType.Terminal)) > 0 // run by a terminal action
                || (updateSource & (UpdateType.Mod)) > 0 // script run by a mod
                || (updateSource & (UpdateType.Script)) > 0 // this pb run by another script (PB)
                )
            {

                if (argument == "start" || argument == "stop" || argument == "projector" || argument == "skip")
                {
                    IGC.SendBroadcastMessage(BroadcastTag, argument);
                    Echo("Sending message: \n" + argument);
                }

                else if (argument == "setup")
                {
                    IGC.SendBroadcastMessage(BroadcastTag, new MyTuple<string, double, float, bool, float>("setup", WaitingCustom, DynamicSpeedCustom, RotorDynamicSpeedCustom, RotorSpeedCustom));
                    Echo($"Sending message: \nsetup");
                }


                else
                {
                    Echo("Command not allowed");
                    LCD.WriteText("Command not allowed");
                }


            }
            ImListening();
            return;

        }

        public void ImListening()
        {
            while (_myBroadcastListener_station.HasPendingMessage)
            {
                var myIGCMessage_fromDrone = _myBroadcastListener_station.AcceptMessage();
                if (myIGCMessage_fromDrone.Tag == BroadcastTag && myIGCMessage_fromDrone.Data is string)
                {
                    LCD.WriteText(myIGCMessage_fromDrone.Data.ToString());
                }

                if (myIGCMessage_fromDrone.Tag == BroadcastTag && myIGCMessage_fromDrone.Data is float)
                {
                    Rotor.TargetVelocityRPM = (float)(myIGCMessage_fromDrone.Data);
                }
            }
        }


    }
}
